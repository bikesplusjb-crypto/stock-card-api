-- 22 Sept: cg_match_identity ranks candidates; it no longer implies verification.
--   * "number in set" / "year and set" only when the SET actually matched: the set code, a set name
--     on both sides that agrees, or base set on both sides (scan set blank AND checklist row has no
--     subset). A blank scan set against a named set is only "number, same brand" -- it used to count
--     as a full set match, so a blank-set Topps #1 matched every Topps product's #1.
--   * No points for a parallel the model is sure of -- that matched nothing.
--   * An owned CardGauge card is a candidate only for a scan of the same parallel and print run.
--   * Bands renamed to ranks: likely / possible / weak / none (was exact / strong / candidate).
-- Rollback: db/2026-09-22_cg_match_identity_ROLLBACK.sql (the previous definition, verbatim).
create or replace function public.cg_match_identity(p jsonb)
 returns jsonb
 language plpgsql
 stable security definer
 set search_path to 'public', 'extensions'
as $function$
declare
  v_game   text := lower(coalesce(nullif(p->>'game',''), ''));
  v_year   int  := case when (p->>'year') ~ '^\d{4}$' then (p->>'year')::int end;
  v_brand  text := lower(nullif(trim(p->>'brand'),''));
  v_set    text := lower(nullif(trim(p->>'set_name'),''));
  v_code   text := lower(nullif(trim(p->>'set_code'),''));
  v_num    text := public.cg_norm_number(p->>'card_number');
  v_player text := lower(nullif(trim(p->>'player'),''));
  v_lang   text := coalesce(nullif(p->>'language',''), 'en');
  v_cy     int  := case when (p->>'copyright_year') ~ '^\d{4}$' then (p->>'copyright_year')::int end;
  v_par    text := lower(trim(regexp_replace(coalesce(p->>'parallel',''), '\s*parallel\s*', ' ', 'gi')));
  v_run    int  := case when coalesce(p->>'serial','') ~ '\d+\s*$'
                        then (substring(p->>'serial' from '(\d+)\s*$'))::int end;
  v_alias  text := public.cg_norm(p->>'alias');
  v_out    jsonb;
  v_seen   int;
begin
  if v_game like 'pok%' or v_brand like 'pok%' then v_game := 'pokemon'; end if;
  if v_num is null and v_player is null then
    return jsonb_build_object('candidates', '[]'::jsonb, 'best', null, 'band', 'none', 'seen_before', 0,
                              'reason', 'nothing to match on');
  end if;

  with ref as (
    select 'ref'::text as kind, r.source || ':' || r.source_id as ref_id, null::uuid as card_id,
           r.year, r.brand, r.set_name, r.set_code, r.card_number, r.subject, r.image_url, r.source
      from public.ref_cards r
     where (v_game = '' or r.game = v_game)
       and r.language = v_lang
       and v_num is not null
       and public.cg_norm_number(r.card_number) = v_num
       and (v_year is null or v_code is not null or r.year between v_year - 1 and v_year + 1)
     limit 400
  ),
  owned as (
    select 'card'::text, c.card_id::text, c.card_id, c.year, c.brand, c.set_name, c.set_code, c.card_number,
           c.player, null::text, 'cardgauge'::text
      from public.cards c
     where c.status = 'confirmed'
       and (v_year is null or c.year = v_year)
       and ((v_num is not null and public.cg_norm_number(c.card_number) = v_num)
            or (v_num is null and lower(c.player) = v_player))
       -- same variant only: a confirmed base card is not evidence for a Blue /149
       and lower(trim(regexp_replace(coalesce(c.parallel,''), '\s*parallel\s*', ' ', 'gi'))) = v_par
       and coalesce(c.print_run, -1) = coalesce(v_run, -1)
     limit 50
  ),
  pool as (select * from ref union all select * from owned),
  scored as (
    select pl.*,
      ((v_code is not null and lower(pl.set_code) = v_code)
        or (v_brand is not null and lower(coalesce(pl.brand,'')) = v_brand
            and ((v_set is null and pl.set_name is null)      -- base set on both sides
                 or (v_set is not null and pl.set_name is not null
                     and (lower(pl.set_name) = v_set
                          or position(lower(pl.set_name) in v_set) > 0 or position(v_set in lower(pl.set_name)) > 0)))))
        as set_ok,
      (v_brand is not null and lower(coalesce(pl.brand,'')) = v_brand) as brand_ok,
      (v_player is not null and pl.subject is not null
        and (extensions.similarity(lower(pl.subject), v_player) >= 0.45
             or position(lower(pl.subject) in v_player) > 0 or position(v_player in lower(pl.subject)) > 0))
        as subj_ok,
      (v_year is not null and pl.year = v_year) as year_ok
    from pool pl
  ),
  pts as (
    select s.*,
      (case when s.set_ok and v_num is not null then 35
            when s.brand_ok and v_num is not null then 20 else 0 end)
    + (case when s.subj_ok then 25 else 0 end)
    + (case when s.year_ok and s.set_ok then 15 else 0 end)
    + (case when v_cy is not null and s.year = v_cy then 10 else 0 end)
    + (case when s.card_id is not null and v_alias is not null and exists (
            select 1 from public.card_aliases a where a.alias_norm = v_alias and a.card_id = s.card_id and a.times_seen >= 2)
            then 10 else 0 end)
    - (case when s.card_id is not null and exists (
            select 1 from public.card_corrections cc where cc.from_card_id = s.card_id and cc.status = 'accepted')
            then 40 else 0 end) as score,
      array_remove(array[
        case when s.set_ok and v_num is not null then 'number in set'
             when s.brand_ok and v_num is not null then 'number, same brand' end,
        case when s.subj_ok then 'name matches' end,
        case when s.year_ok and s.set_ok then 'year and set' end,
        case when v_cy is not null and s.year = v_cy then 'copyright year' end], null) as evidence
    from scored s
  ),
  top as (
    select * from pts where score > 0
     order by score desc, (kind = 'card') desc, year desc nulls last
     limit 3
  )
  select jsonb_build_object(
    'candidates', coalesce(jsonb_agg(jsonb_build_object(
        'kind', kind, 'id', ref_id, 'card_id', card_id, 'source', source,
        'year', year, 'brand', brand, 'set_name', set_name, 'set_code', set_code,
        'card_number', card_number, 'name', subject, 'image_url', image_url,
        'score', greatest(0, least(100, score)), 'evidence', to_jsonb(evidence))
        order by score desc), '[]'::jsonb))
    into v_out
    from top;

  select count(*) into v_seen
    from public.cards c2
   where c2.status = 'observed' and v_num is not null
     and public.cg_norm_number(c2.card_number) = v_num
     and (v_year is null or c2.year = v_year)
     and (v_player is null or lower(c2.player) = v_player);

  -- Ranks, not verdicts. Nothing here says the photo IS this card.
  return v_out || jsonb_build_object(
    'seen_before', v_seen,
    'best', v_out #> '{candidates,0}',
    'band', case when (v_out #>> '{candidates,0,score}')::int >= 85 then 'likely'
                 when (v_out #>> '{candidates,0,score}')::int >= 70 then 'possible'
                 when v_out #> '{candidates,0}' is not null then 'weak'
                 else 'none' end);
end $function$;
