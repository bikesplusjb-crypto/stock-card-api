-- 22 Sept: outcome-tracking foundation on the table BuyMax already logs to.
-- Additive only. Old servers ignore the new columns; the new server needs them.
alter table public.buymax_analyses
  add column if not exists decision_record    jsonb,        -- the canonical record, whole
  add column if not exists canonical_decision text,         -- BUY / WALK_AWAY / REVIEW / NO_DECISION
  add column if not exists evidence_quality   text,         -- HIGH / MODERATE / THIN / ... / NONE
  add column if not exists outcome_bought_at  timestamptz,  -- when "bought" was reported
  add column if not exists outcome_sold_at    timestamptz;  -- when "sold" was reported (time to sale)
create index if not exists buymax_analyses_canonical_idx on public.buymax_analyses (canonical_decision, created_at desc);
comment on column public.buymax_analyses.decision_record is
  'Canonical decision record (buymax.js core/record, version in decision_record->>version). Confidence inside is an evidence rating, not a calibrated probability.';
-- Rollback:
--   drop index if exists public.buymax_analyses_canonical_idx;
--   alter table public.buymax_analyses drop column if exists decision_record, drop column if exists canonical_decision,
--     drop column if exists evidence_quality, drop column if exists outcome_bought_at, drop column if exists outcome_sold_at;
