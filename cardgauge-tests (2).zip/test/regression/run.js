#!/usr/bin/env node
/* ══════════════════════════════════════════════════════════════════
   REGRESSION SUITE — REAL SCANS THROUGH THE REAL ROUTE, NO NETWORK
   21 Sept 2026

   Every row in scan_reads is a card somebody actually scanned or typed.
   This takes each row's FINAL identity (after corrections) and pushes it
   through the live POST /api/scan-card handler in server.js -- the same
   code Render runs, loaded unmodified -- with everything that touches
   the outside world replaced:

     vision            -> returns the row's final identity
     eBay listings     -> three fixed scenarios per row (see MARKET below)
     thecardapi sold   -> sold_comps_cache payloads (fixtures/sold_cache.txt)
     catalog, OpenAI,
     Meta, Supabase    -> stubbed to "nothing found"

   Nothing leaves this machine. A sold query that is not in the cache
   fixture is recorded as MISS and treated as "no data", so the suite
   never spends a single record of the daily allowance.

   WHAT IT RECORDS per row per scenario: the tier queries, the query the
   price came from, basis (median / limited / refused / none), and every
   correction field the response carries. Those are written to
   results/<label>.json. Run it once before a change and once after, then
   diff:

     node test/regression/run.js --label before
     ...edit server.js...
     node test/regression/run.js --label after
     node test/regression/diff.js before after

   Any row whose query, basis or refusal changes is printed with the old
   and new values side by side. A change is not automatically a bug --
   but every one has to be explained before it ships.

   REFRESHING THE FIXTURES. fixtures/*.txt were pulled from Supabase on
   21 Sept. To refresh them run the two SQL statements in
   fixtures/README.md in the Supabase SQL editor and paste the output
   over the old files. The suite does not read Supabase itself on
   purpose: a test that changes when production data changes cannot tell
   you whether the CODE changed.
   ══════════════════════════════════════════════════════════════════ */
"use strict";

const fs     = require("fs");
const path   = require("path");
const Module = require("module");

const ROOT     = path.resolve(__dirname, "..", "..");
const FIX      = path.join(__dirname, "fixtures");
const OUT      = path.join(__dirname, "results");

const argv  = process.argv.slice(2);
const label = (function () {
  const i = argv.indexOf("--label");
  return i >= 0 ? argv[i + 1] : "run";
})();
/* --bodies writes the full "logged" response per row to
   results/<label>.bodies.json, for checking the scanner's rendering
   logic against real responses. */
const bodiesOut = argv.indexOf("--bodies") >= 0 ? {} : null;
/* --stream also runs every row with stream=1 -- see streamCheck(). */
const checkStream = argv.indexOf("--stream") >= 0;
const streamProblems = [];
let streamChecked = 0;
const only = (function () {
  const i = argv.indexOf("--id");
  return i >= 0 ? Number(argv[i + 1]) : null;
})();

/* ── 1. Environment: a key so getSoldComps does not short-circuit, no
         Supabase so nothing is written, fixed clock for the year logic. */
process.env.CARDAPI_KEY = "regression-suite-no-network";
delete process.env.SUPABASE_URL;
delete process.env.SUPABASE_SERVICE_ROLE_KEY;
delete process.env.OPENAI_API_KEY;
delete process.env.STRIPE_SECRET_KEY;

/* Timers created at load time (limiter sweeps, caches) must not keep
   the process alive. */
const _si = global.setInterval;
global.setInterval = function () { const t = _si.apply(this, arguments); if (t && t.unref) t.unref(); return t; };

/* ── 2. Module mocks. Anything that could open a socket is replaced. */
let netCalls = 0;
const routes = {};
function chain() {
  const fn = function () { return proxy; };
  const proxy = new Proxy(fn, {
    get(_t, k) {
      if (k === "then") return undefined;
      return proxy;
    },
    apply() { return proxy; }
  });
  return proxy;
}
function fakeApp() {
  const app = {
    set() {}, use() {}, listen() { return { close() {} }; },
    get(p)  { routes["GET " + p]  = arguments[arguments.length - 1]; },
    post(p) { routes["POST " + p] = arguments[arguments.length - 1]; },
    put() {}, delete() {}, options() {}, all() {}
  };
  return app;
}
const express = function () { return fakeApp(); };
express.json = () => (q, s, n) => n && n();
express.urlencoded = express.json;
express.raw = express.json;
express.static = express.json;
express.Router = () => fakeApp();

const mocks = {
  "express": express,
  "cors": () => (q, s, n) => n && n(),
  "multer": Object.assign(function () {
    const mw = () => (q, s, n) => n && n();
    return { fields: mw, single: mw, array: mw, any: mw, none: mw };
  }, { memoryStorage: () => ({}), MulterError: Error }),
  "node-fetch": function () {
    netCalls++;
    return Promise.reject(new Error("regression suite: network disabled"));
  },
  "node-cron": { schedule() { return { stop() {} }; } },
  "@supabase/supabase-js": { createClient: () => chain() },
  /* The real engine module, minus the route mount: buildEvidenceReceipt
     grades pools with buymax.js's own evidenceQuality (22 Sept). Pure
     functions, no network. */
  "./buymax": Object.assign({}, require(path.join(__dirname, "../../buymax")), { mountBuyMax() {} }),
  "./buymax-adapter": { makeCardGaugeHook() { return function () {}; } }
};
const origLoad = Module._load;
Module._load = function (request, parent, isMain) {
  if (Object.prototype.hasOwnProperty.call(mocks, request)) return mocks[request];
  return origLoad.apply(this, arguments);
};
global.fetch = mocks["node-fetch"];

/* ── 3. Load server.js UNMODIFIED, plus one appended line that lets the
         suite swap a function declaration from outside. Function
         declarations are ordinary mutable bindings, so the route picks
         up the stub on its next call. */
const serverPath = path.join(ROOT, "server.js");
const src = fs.readFileSync(serverPath, "utf8") +
  "\n;module.exports.__stub = function (n, f) { eval(n + ' = f'); };" +
  "\n;module.exports.__get  = function (n) { return eval(n); };\n";
const m = new Module(serverPath, module);
m.filename = serverPath;
m.paths = Module._nodeModulePaths(ROOT);
const quiet = console.log;
console.log = function () {};           // server.js logs a lot at load
m._compile(src, serverPath);
const S = m.exports;

/* ── 4. Fixtures. */
function readLines(f) {
  return fs.readFileSync(path.join(FIX, f), "utf8").split("\n")
    .filter(l => l.trim() && l[0] !== "#");
}
const sports = {};
fs.readFileSync(path.join(FIX, "sports.txt"), "utf8").trim().split(",").forEach(p => {
  const i = p.indexOf(":"); sports[p.slice(0, i)] = p.slice(i + 1);
});
const rows = readLines("scan_reads.txt").concat(readLines("synthetic.txt")).map(l => {
  /* id|surface|copyrightYear|finalJSON|sold_query|sold_median|sold_count|sold_basis
     The JSON can itself contain "|" in theory, so split from both ends. */
  const a = l.split("|");
  const head = a.slice(0, 3), tail = a.slice(-4);
  const json = a.slice(3, a.length - 4).join("|");
  const final = JSON.parse(json);
  if (sports[head[0]]) final.sport = sports[head[0]];
  return {
    id: Number(head[0]), surface: head[1], copyrightYear: head[2], final,
    logged: { soldQuery: tail[0], median: tail[1] ? Number(tail[1]) : null,
              count: tail[2] ? Number(tail[2]) : null, basis: tail[3] }
  };
});
const cache = {};
readLines("sold_cache.txt").forEach(l => {
  const a = l.split("|");
  const n = a.length;
  /* key may contain "|"? never in practice; join defensively */
  const key = a.slice(0, n - 10).join("|");
  const v = a.slice(n - 10);
  cache[key] = {
    soldCount: Number(v[0]), soldMedian: Number(v[1]),
    soldLimited: v[2] === "1", soldContaminated: v[3] === "1", soldIsSealed: v[4] === "1",
    soldRaw: { count: Number(v[5]), low: v[6] === "" ? null : Number(v[6]),
               high: v[7] === "" ? null : Number(v[7]), median: 0 },
    soldBasis: v[8], soldWideBase: v[9] === "1"
  };
});

/* BACKFILL FROM WHAT PRODUCTION LOGGED. sold_comps_cache only keeps
   recent rows, so most of the older scans' queries are gone from it. But
   every scan_reads row records the outcome of the query its price came
   from -- count, median, basis. That is enough for the selection logic
   (it reads count, median, limited, contaminated, raw.count/low/high),
   so those outcomes are added for any query the cache no longer holds.
   Marked synth so a diff can say which evidence it rests on. Real cache
   rows always win. */
let synthAdded = 0;
function cacheKey(q) { return S.__get("cacheKeyFor")(q, S.__get("CARDAPI_LIMIT")); }
rows.forEach(r => {
  const L = r.logged;
  if (r.id >= 9000 || !L.soldQuery) return;    // synthetic rows never backfill
  const k = cacheKey(L.soldQuery);
  if (!k || cache[k]) return;
  const med = L.median || 0, cnt = L.count || 0;
  cache[k] = {
    soldCount: cnt, soldMedian: med,
    soldLimited: L.basis === "limited", soldContaminated: L.basis === "mixed",
    soldIsSealed: false,
    soldRaw: { count: L.basis === "raw" ? cnt : 0, low: med || null, high: med || null, median: med },
    soldBasis: L.basis, soldWideBase: false, synth: true
  };
  synthAdded++;
});

/* ── 5. Stubs. */
let current = null;           // the row being run
let trace = [];               // sold queries asked for this run
const CARDAPI_LIMIT = S.__get("CARDAPI_LIMIT");
S.__stub("scanWithOpenAI", async function () {
  const ai = JSON.parse(JSON.stringify(current.final));
  /* The model returns strings; typed rows stored numbers. */
  if (ai.year != null) ai.year = String(ai.year);
  ai.copyrightLine = current.copyrightYear
    ? "© " + current.copyrightYear + " THE COMPANY, INC." : "";
  if (ai.parallelCertain == null) ai.parallelCertain = true;
  return ai;
});
S.__stub("readCopyrightStrip",   async () => null);
S.__stub("verifyAgainstCatalog", async () => ({ checked: false }));
S.__stub("lookupCorrections",    async () => null);
S.__stub("sendMetaEvent",        () => {});
S.__stub("recordDailyPriceFromLookup", () => {});
S.__stub("logScanRead",          () => {});
/* The local identity lookup is a Postgres call. Stubbed to "no match"
   for every real row, so they run exactly the catalog path they ran in
   production; synthetic row 9003 gets the sure TCGdex match the live
   database returns for PFL 030 Yamper, to exercise the local-first path. */
let catalogCalls = 0;
S.__stub("catalogYearCheck",     async () => { catalogCalls++; return null; });
S.__stub("catalogSetFill",       async () => { catalogCalls++; return null; });
S.__stub("matchLocalIdentity", async function () {
  if (!current || current.id !== 9003) return null;
  return { band: "candidate", seenBefore: 0, candidates: 1, best: {
    source: "tcgdex", id: "tcgdex:en:me02-030", card_id: null, year: 2025, brand: "Pokemon",
    set_name: "Phantasmal Flames", set_code: "PFL", card_number: "030", name: "Yamper", score: 75,
    evidence: ["number in set", "name matches", "year and set"], image_url: null } };
});

/* MARKET. Real listings are not stored anywhere, so the suite runs every
   card three ways: as if the tight listing search found plenty
   ("tight"), as if it came back thin and settled on the core tier
   ("thin"), and starting from the query production actually logged
   ("logged"). Between them they exercise both sides of every branch that
   reads market.tierUsed -- the [sold-precise] block never runs on
   "tight". */
const SCENARIOS = ["tight", "thin", "logged"];
let scenario = "tight";
S.__stub("getCardMarketForCard", async function (ai) {
  const tiers = S.__get("buildQueryTiers")(ai) || [];
  let pick;
  if (scenario === "tight") {
    pick = tiers.find(t => t.tier === "tight") || tiers[0];
  } else if (scenario === "thin") {
    pick = tiers.find(t => t.tier === "core") || tiers.find(t => t.tier === "loose") || tiers[tiers.length - 1];
  } else {
    /* "logged": the listing search landed where production says it did.
       scan_reads does not store market.searchQuery, but when no correction
       fired, sold_query IS the listing query -- so this replays the real
       starting point for most rows. */
    const lq = current.logged.soldQuery;
    pick = tiers.find(t => t.query === lq) || { tier: "core", query: lq };
  }
  return {
    searchQuery: pick ? pick.query : (ai.cardName || ""),
    tierUsed: pick ? pick.tier : "fallback",
    matchQuality: scenario === "tight" ? "exact" : "loose",
    avgPrice: 0, lowPrice: 0, highPrice: 0, listingCount: 0,
    listings: [], raw: null, graded: null, gradeBreakdown: [],
    priceNote: "", spreadNote: ""
  };
});
S.__stub("getSoldComps", async function (query) {
  const key = S.__get("cacheKeyFor")(query, CARDAPI_LIMIT);
  const hit = key && cache[key];
  trace.push({ q: query, hit: !!hit, synth: !!(hit && hit.synth) });
  if (!hit) return null;                    // MISS == no data, never a fetch
  return S.__get("sealedSanityCheck")(JSON.parse(JSON.stringify(hit)), 0);
});

/* ── 6. Run. */
function basisOf(r) {
  const s = r.sold;
  if (!s) return "none";
  if (s.mixedSerials) return "range";
  if (s.soldContaminated) return "refused:contaminated";
  if (s.soldLimited) return "refused:limited";
  if (Number(s.soldMedian) > 0) return "priced";
  return "none";
}

/* STREAM CHECK. Runs the same row with stream=1 and confirms the
   progressive response is the plain one plus an early identity line:
   the final NDJSON line must equal the plain body (bar timestamp and the
   stage marker), and every identity field sent early must match the
   final value. Returns a list of problems, empty when it holds. */
async function streamCheck(row, plainBody) {
  current = row; trace = [];
  const chunks = [];
  let sent = false, status = 200;
  const req = {
    files: { front: [{ size: 1024, buffer: Buffer.alloc(1) }],
             back: row.surface === "scan_b" ? [{ size: 1024, buffer: Buffer.alloc(1) }] : undefined },
    body: { stream: "1" }, headers: {}, query: {}, ip: "127.0.0.1"
  };
  const res = {
    get headersSent() { return sent; },
    status(c) { status = c; return res; }, setHeader() {}, set() { return res; },
    write(x) { sent = true; chunks.push(String(x)); return true; },
    end(x) { sent = true; if (x) chunks.push(String(x)); },
    json(b) { sent = true; chunks.push(JSON.stringify(b)); return res; }
  };
  await routes["POST /api/scan-card"](req, res, () => {});
  const problems = [];
  const lines = chunks.join("").split("\n").filter(Boolean).map(l => JSON.parse(l));
  if (!plainBody || !plainBody.success) {
    /* A refused scan never reaches the identity point: one plain body. */
    if (lines.length !== 1 || lines[0].stage) problems.push("unidentified card should not stream");
    return problems;
  }
  if (lines.length !== 2) { problems.push("expected 2 lines, got " + lines.length); return problems; }
  const [early, fin] = lines;
  if (early.stage !== "identity") problems.push("first line stage=" + early.stage);
  if (fin.stage !== "final") problems.push("last line stage=" + fin.stage);
  const a = Object.assign({}, fin); delete a.stage; delete a.timestamp;
  const b = Object.assign({}, plainBody); delete b.timestamp;
  if (JSON.stringify(a) !== JSON.stringify(b)) problems.push("final line differs from plain body");
  Object.keys(early).forEach(k => {
    if (k === "stage" || k === "visionMs") return;
    if (JSON.stringify(early[k]) !== JSON.stringify(fin[k])) problems.push("identity." + k + " " + JSON.stringify(early[k]) + " != final " + JSON.stringify(fin[k]));
  });
  return problems;
}

async function runOne(row) {
  current = row; trace = []; catalogCalls = 0;
  let body = null, status = 200;
  const req = {
    files: { front: [{ size: 1024, buffer: Buffer.alloc(1) }],
             back: row.surface === "scan_b" ? [{ size: 1024, buffer: Buffer.alloc(1) }] : undefined },
    body: {}, headers: {}, query: {}, ip: "127.0.0.1"
  };
  const res = {
    status(c) { status = c; return res; },
    json(b) { body = b; return res; },
    set() { return res; }, setHeader() {}
  };
  await routes["POST /api/scan-card"](req, res, () => {});
  const tiers = (S.__get("buildQueryTiers")(Object.assign({}, row.final,
    { year: row.final.year != null ? String(row.final.year) : row.final.year })) || [])
    .map(t => t.tier + "=" + t.query);
  if (!body || !body.success) {
    return { status, error: body && body.error, tiers, asked: trace };
  }
  if (bodiesOut && scenario === "logged") bodiesOut[row.id] = body;
  if (checkStream && scenario === "logged") {
    const probs = await streamCheck(row, body);
    if (probs.length) streamProblems.push("#" + row.id + ": " + probs.join("; "));
    streamChecked++;
  }
  const out = {
    status,
    tiers,
    searchQuery: body.searchQuery,
    soldQuery:   body.soldQuery,
    basis:       basisOf(body),
    median:      body.sold ? Number(body.sold.soldMedian) || 0 : 0,
    soldCount:   body.soldCount,
    preciseTier: body.sold && body.sold.soldPreciseTier || null,
    broadened:   body.soldBroadened ? body.soldBroadened.tier : null,
    yearGuess:   body.yearGuess ? body.yearGuess.claimedYear + "->" + body.yearGuess.triedYear : null,
    yearCheck:   body.yearCheck || null,
    serialDropped: !!body.serialDropped,
    parallelCertain: body.parallelCertain,
    shownSet:    body.set,
    verifiedSource: body.verified ? (body.verified.source || (body.verified.checked ? "catalog" : "unchecked")) : null,
    parallelConfidence: body.parallelConfidence,
    keys:        Object.keys(body).sort().join(","),
    asked:       trace,
    misses:      trace.filter(t => !t.hit).length,
    catalogCalls: catalogCalls
  };
  return out;
}

(async function main() {
  const results = {};
  const sel = only ? rows.filter(r => r.id === only) : rows;
  for (const row of sel) {
    results[row.id] = { surface: row.surface, logged: row.logged, runs: {} };
    for (const sc of SCENARIOS) {
      scenario = sc;
      try { results[row.id].runs[sc] = await runOne(row); }
      catch (e) { results[row.id].runs[sc] = { crash: String(e && e.stack || e) }; }
    }
  }
  console.log = quiet;
  if (!fs.existsSync(OUT)) fs.mkdirSync(OUT);
  const file = path.join(OUT, label + ".json");
  fs.writeFileSync(file, JSON.stringify(results, null, 1));
  if (bodiesOut) fs.writeFileSync(path.join(OUT, label + ".bodies.json"), JSON.stringify(bodiesOut));

  /* Summary. */
  const ids = Object.keys(results);
  let crashes = 0, priced = 0, refused = 0, none = 0, range = 0, errors = 0, asked = 0, miss = 0;
  ids.forEach(id => SCENARIOS.forEach(sc => {
    const r = results[id].runs[sc];
    if (r.crash) { crashes++; return; }
    if (r.error) { errors++; return; }
    asked += r.asked.length; miss += r.misses;
    if (r.basis === "priced") priced++;
    else if (r.basis === "range") range++;
    else if (r.basis.indexOf("refused") === 0) refused++;
    else none++;
  }));
  console.log("regression: " + ids.length + " rows x " + SCENARIOS.length + " scenarios -> " + file);
  console.log("  priced " + priced + " | range " + range + " | refused " + refused +
              " | none " + none + " | route error " + errors + " | CRASH " + crashes);
  console.log("  sold lookups " + asked + " (cache hits " + (asked - miss) + ", misses " + miss +
              ") | network calls attempted: " + netCalls);
  /* FIDELITY: on the "logged" scenario, how often does the suite land on
     the same sold query and the same priced/unpriced outcome production
     logged? Low fidelity means the stubs are hiding something, not that
     the code is wrong -- read it before trusting a diff. Typed rows go
     through a different route in production, so only scans count. */
  let fq = 0, fb = 0, fn = 0, fnd = 0, fbd = 0;
  ids.forEach(id => {
    const R = results[id];
    if (R.surface.indexOf("scan") !== 0 || Number(id) >= 9000) return;
    /* R.logged is what production recorded; R.logged is NOT the run --
       the scenario result lives under the same name, so read it by key. */
    const L = R.logged, run = R.runs && R.runs.logged;
    if (!run || run.crash || run.error) return;
    fn++;
    if (run.soldQuery === L.soldQuery) fq++;
    const lp = L.median > 0, rp = run.median > 0 && run.basis === "priced";
    if (lp === rp) fb++;
    /* Rows where the first lookup had data: the only ones where a
       disagreement could mean the code differs rather than the cache. */
    if (run.asked[0] && run.asked[0].hit) { fnd++; if (lp === rp) fbd++; }
  });
  console.log("  fidelity vs production (scans, 'logged' scenario): same sold query " + fq + "/" + fn +
              ", same priced/unpriced " + fb + "/" + fn +
              " (" + fbd + "/" + fnd + " where the first lookup had data)");
  console.log("  cache: " + Object.keys(cache).length + " queries (" + synthAdded +
              " backfilled from scan_reads outcomes)");
  if (checkStream) {
    console.log("  stream check: " + streamChecked + " rows, " + streamProblems.length + " problems");
    streamProblems.slice(0, 20).forEach(p => console.log("    " + p));
  }
  if (only) console.log(JSON.stringify(results[only], null, 1));
  if (crashes || netCalls || streamProblems.length) process.exitCode = 1;
})();
