# Regression fixtures

Pulled from Supabase project `nlaqvfplecacbbdbmhxd` on 21 Sept 2026. The suite reads these files and never Supabase itself, so a change in results always means a change in the code.

## Refresh

Run each statement in the Supabase SQL editor. Paste the single cell it returns over the file named.

**scan_reads.txt**
```sql
select string_agg(format('%s|%s|%s|%s|%s|%s|%s|%s', id, left(surface,6),
  coalesce(substring(final->>'copyrightLine' from '(19[5-9][0-9]|20[0-4][0-9])'),''),
  (select jsonb_object_agg(k,v) from jsonb_each(final) e(k,v)
     where v not in ('null','false','""','[]')
       and k not in ('confidence','summary','signal','copyrightLine','parallelCertain','sport')),
  coalesce(sold_query,''), coalesce(sold_median::text,''), coalesce(sold_count::text,''),
  coalesce(sold_basis,'')), E'\n' order by id)
from scan_reads;
```

**sports.txt**
```sql
select string_agg(id||':'||(final->>'sport'), ',' order by id) from scan_reads where final ? 'sport';
```

**sold_cache.txt** (keep the `#` header line)
```sql
select string_agg(format('%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s', cache_key,
  coalesce(payload->>'soldCount','0'), coalesce(payload->>'soldMedian','0'),
  case when (payload->>'soldLimited')::bool then 1 else 0 end,
  case when (payload->>'soldContaminated')::bool then 1 else 0 end,
  case when (payload->>'soldIsSealed')::bool then 1 else 0 end,
  coalesce(payload->'soldRaw'->>'count','0'), coalesce(payload->'soldRaw'->>'low',''),
  coalesce(payload->'soldRaw'->>'high',''), coalesce(payload->>'soldBasis',''),
  case when (payload->>'soldWideBase')::bool then 1 else 0 end), E'\n' order by cache_key)
from sold_comps_cache;
```

Refreshing changes the baseline. Always run `--label before` on the **unchanged** code straight after a refresh, and never compare runs from two different fixture sets.

## Limits

- `sold_comps_cache` only holds recent rows. For older scans, the suite rebuilds the outcome of the query production actually priced from, using the `scan_reads` row (count, median, basis). Any other query for those cards is a MISS, which is treated as no data.
- Real eBay listings are not stored, so each card runs three market scenarios: `tight`, `thin` and `logged`.
- Catalog verification, the catalog year fix, learned corrections and the strip reader are stubbed to "nothing found". Those paths are not covered.
