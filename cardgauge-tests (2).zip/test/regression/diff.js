#!/usr/bin/env node
/* Compare two regression runs.

     node test/regression/diff.js before after

   Prints every row and scenario whose sold query, basis (priced / range /
   refused / none), median, precise tier, broadening tier or year handling
   changed -- plus any change to the SET of response keys, since the
   response shape is a contract the scanners depend on. Exit code 1 if
   anything changed, so it can gate a deploy. */
"use strict";
const fs = require("fs");
const path = require("path");

const [a, b] = process.argv.slice(2);
if (!a || !b) { console.error("usage: diff.js <labelA> <labelB>"); process.exit(2); }
const load = l => JSON.parse(fs.readFileSync(path.join(__dirname, "results", l + ".json"), "utf8"));
const A = load(a), B = load(b);

const FIELDS = ["soldQuery", "basis", "median", "preciseTier", "broadened", "yearGuess",
                "serialDropped", "parallelCertain", "parallelConfidence", "error", "crash"];
let changed = 0, keysChanged = 0;
const addedKeys = new Set();
const out = [];

Object.keys(A).forEach(id => {
  if (!B[id]) { out.push("#" + id + " missing from " + b); changed++; return; }
  Object.keys(A[id].runs).forEach(sc => {
    const x = A[id].runs[sc], y = B[id].runs[sc] || {};
    const diffs = FIELDS.filter(f => JSON.stringify(x[f]) !== JSON.stringify(y[f]));
    if (diffs.length) {
      changed++;
      out.push("#" + id + " [" + sc + "] " + A[id].surface);
      diffs.forEach(f => out.push("    " + f + ": " + JSON.stringify(x[f]) + "  ->  " + JSON.stringify(y[f])));
    }
    /* New optional keys are expected when a feature adds a field; a key
       that DISAPPEARS breaks a scanner. Report both, label them. */
    if (x.keys && y.keys && x.keys !== y.keys) {
      const xs = new Set(x.keys.split(",")), ys = new Set(y.keys.split(","));
      const gone = [...xs].filter(k => !ys.has(k)), added = [...ys].filter(k => !xs.has(k));
      if (gone.length) { keysChanged++; out.push("#" + id + " [" + sc + "] RESPONSE KEYS REMOVED: " + gone.join(",")); }
      added.forEach(k => addedKeys.add(k));
    }
  });
});

if (addedKeys.size) out.push("(new response keys: " + [...addedKeys].join(",") + " -- additive, existing keys intact)");
console.log(out.join("\n") || "no changes");
console.log("\n" + changed + " row/scenario changes, " + keysChanged + " with removed response keys");
process.exitCode = (changed || keysChanged) ? 1 : 0;
