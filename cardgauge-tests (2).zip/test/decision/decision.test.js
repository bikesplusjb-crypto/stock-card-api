'use strict';
/* Decision foundation tests (22 Sept). Run: node --test test/decision/
   Real BuyMax engine + real adapter refusals; only the data sources are stubbed. */
const test = require('node:test');
const assert = require('node:assert/strict');
const { run, pool, listings, SCENARIOS } = require('./scenarios');
const { decisionRecord } = require('../../buymax');

const go = async (name) => {
  const r = await run(SCENARIOS[name]);
  assert.equal(r.status, 200, name + ' status');
  return { p: r.payload, rec: r.payload.decision_record };
};
const assertRecordShape = (rec) => {
  for (const k of ['version', 'action', 'why', 'market', 'economics', 'evidence', 'identity', 'risk',
                   'confidence', 'assumptions', 'alternatives', 'what_would_change']) {
    assert.ok(k in rec, 'record has ' + k);
  }
  assert.ok(decisionRecord.ACTIONS.includes(rec.action));
  assert.equal(rec.confidence.meaning, decisionRecord.CONFIDENCE_MEANING, 'confidence is labelled as not a probability');
  assert.ok(!/%/.test(String(rec.confidence.level)), 'confidence is a word, never a percentage');
};

test('1. strong sold evidence + good ask -> BUY', async () => {
  const { p, rec } = await go('strong_buy');
  assertRecordShape(rec);
  assert.equal(p.decision.result, 'BUY');
  assert.equal(rec.action, 'BUY');
  assert.equal(rec.evidence.quality, 'HIGH');
  assert.equal(rec.confidence.level, 'HIGH');
  assert.ok(rec.what_would_change.length > 0);
});

test('2. strong evidence + bad economics -> WALK_AWAY (not NO_DECISION)', async () => {
  const { p, rec } = await go('strong_walk_away');
  assert.equal(p.decision.result, 'PASS');
  assert.equal(rec.action, 'WALK_AWAY');
  assert.notEqual(rec.confidence.level, 'NONE', 'a walk-away is a decision');
  assert.ok(rec.what_would_change.some((x) => x.indexOf(String(Math.round(rec.economics.maximum_buy))) > -1),
    'names the ceiling the seller would have to come down to');
});

test('3. insufficient evidence (2 sales) -> NO_DECISION', async () => {
  const { p, rec } = await go('insufficient_two');
  assert.equal(p.decision.no_call, true);
  assert.equal(rec.action, 'NO_DECISION');
  assert.equal(rec.evidence.quality, 'INSUFFICIENT');
  assert.equal(rec.confidence.level, 'NONE');
  assert.equal(rec.economics.maximum_buy, null, 'no ceiling printed on a no-decision');
  assert.equal(rec.market.value, null, 'no market value from two sales');
  assert.equal(rec.market.sold_count, 2, 'the count stays: it is the reason');
});

test('4. one isolated sale + plenty of asks -> never BUY', async () => {
  const { p, rec } = await go('one_sale_plus_asks');
  assert.notEqual(p.decision.result, 'BUY');
  assert.equal(rec.action, 'NO_DECISION');
});

test('5. active-only evidence -> NO_DECISION, labelled asking prices only', async () => {
  const { rec } = await go('active_only');
  assert.equal(rec.action, 'NO_DECISION');
  assert.equal(rec.evidence.quality, 'ACTIVE_ONLY');
});

test('5b. active-only estimate with sold-first on -> no BUY/PASS from asks', async () => {
  // A provider that returns no sold data at all (not a refusal) and 8 listings.
  const { runBuyMax, config } = require('../../buymax');
  const cardgauge = { name: 'cardgauge', kind: 'intelligence', isConfigured: () => true,
    fetch: async () => ({ available: true, identity: null, identity_confidence: 85, sold: null, compguard: null, errors: [] }) };
  const ebay = { name: 'ebay_active', kind: 'marketplace', isConfigured: () => true,
    fetch: async () => ({ available: true, listings: listings(8, 40), errors: [] }) };
  const r = await runBuyMax({ category: 'card', item: { name: '2020 Topps Chrome Luis Robert #1', condition: 'raw' }, asking_price: 5 },
                            { cfg: config, providers: { cardgauge, ebay } });
  assert.notEqual(r.payload.decision.result, 'BUY');
  assert.notEqual(r.payload.decision.result, 'PASS');
  assert.equal(r.payload.decision_record.action, 'NO_DECISION');
});

test('6. contaminated evidence -> NO_DECISION, REFUSED', async () => {
  const { rec } = await go('contaminated');
  assert.equal(rec.action, 'NO_DECISION');
  assert.equal(rec.evidence.quality, 'REFUSED');
});

test('7. mixed variants (wide spread) -> NO_DECISION, REFUSED', async () => {
  const { rec } = await go('mixed_variants');
  assert.equal(rec.action, 'NO_DECISION');
  assert.equal(rec.evidence.quality, 'REFUSED');
  assert.ok(rec.what_would_change[0].toLowerCase().indexOf('one version') > -1);
});

test('8. grade uncertainty lowers confidence and is named', async () => {
  const strong = (await go('strong_buy')).rec;
  const { rec } = await go('grade_unknown');
  assert.equal(strong.confidence.level, 'HIGH');
  assert.notEqual(rec.confidence.level, 'HIGH');
  assert.ok(rec.confidence.reasons.some((x) => /raw or graded/.test(x)));
});

test('9. numbered card not confirmed -> REVIEW (confirm first), never BUY', async () => {
  const { p, rec } = await go('numbered_unconfirmed');
  assert.equal(p.decision.result, 'REVIEW');
  assert.ok(p.decision.factors.includes('identity_unconfirmed'));
  assert.equal(rec.action, 'REVIEW');
  assert.equal(rec.identity.status, 'uncertain');
  assert.ok(rec.what_would_change.some((x) => /print run/.test(x)));
});

test('10. missing asking price -> 400, no decision invented', async () => {
  const r = await run({ raw: pool(155, 17, 120, 190), ask: undefined });
  assert.equal(r.status, 400);
  assert.equal(r.payload.success, false);
  assert.ok(!r.payload.decision_record || r.payload.decision_record.action === 'NO_DECISION');
});

test('11. no sold comps and no listings -> NO_DECISION, NONE', async () => {
  const { rec } = await go('no_comps');
  assert.equal(rec.action, 'NO_DECISION');
  assert.equal(rec.evidence.quality, 'NONE');
});

test('12. BuyMax integration: the record copies the engine numbers, never recomputes them', async () => {
  for (const name of ['strong_buy', 'strong_walk_away', 'grade_unknown']) {
    const { p, rec } = await go(name);
    assert.equal(rec.economics.maximum_buy, p.price_ladder.maximum_buy_price, name + ' ceiling');
    assert.equal(rec.economics.target_offer, p.price_ladder.target_offer, name + ' target');
    assert.equal(rec.economics.expected_profit, p.economics.expected_profit_at_asking, name + ' profit');
    assert.equal(rec.economics.roi, p.economics.roi_at_asking, name + ' roi');
    assert.equal(rec.market.value, p.decision.estimated_resale, name + ' market');
    assert.equal(rec.ask, p.costs.purchase_price, name + ' ask');
    assert.equal(rec.risk.score, p.risk.score, name + ' risk');
    assert.equal(rec.confidence.engine_score, p.confidence.buymax_confidence, name + ' engine score');
    // expected_net = expected_profit + ask (profit is net minus the price paid)
    assert.ok(Math.abs(rec.economics.expected_net - (rec.economics.expected_profit + rec.ask)) < 0.011, name + ' net');
  }
});

test('12b. borderline ask -> REVIEW with a counter, not WALK_AWAY', async () => {
  const base = await go('strong_buy');
  const max = base.rec.economics.maximum_buy;
  const r = await run({ raw: pool(155, 17, 120, 190), ask: Math.round(max * 1.05) });
  const rec = r.payload.decision_record;
  assert.equal(r.payload.decision.result, 'REVIEW');
  assert.ok(r.payload.decision.factors.includes('borderline'));
  assert.equal(rec.action, 'REVIEW');
  assert.ok(rec.alternatives.some((x) => /Counter/.test(x)));
});

test('13. Flip It (cheapest-sale test) moved into the engine', async () => {
  const clear = await go('floor_clear');
  assert.equal(clear.p.decision.result, 'BUY');
  assert.equal(clear.p.decision.basis, 'sold_floor');
  assert.equal(clear.rec.action, 'BUY');
  assert.equal(clear.rec.economics.maximum_buy, null, 'no ceiling on a mixed pool');
  assert.equal(clear.rec.market.basis, 'lowest_recent_sale');
  // Same arithmetic the panel used: floor - fees - fixed fee - postage - ask
  const c = clear.p.costs;
  const expected = 40 - 40 * c.sell_fee_rate - 0.30 - c.shipping_cost - 5;
  assert.ok(Math.abs(clear.rec.economics.expected_profit - expected) < 0.011);
  assert.notEqual(clear.rec.confidence.level, 'HIGH', 'a mixed pool never reads as high confidence');

  const close = await go('floor_too_close');
  assert.equal(close.rec.action, 'NO_DECISION');

  const unconf = await go('floor_unconfirmed');
  assert.equal(unconf.rec.action, 'REVIEW');
  assert.equal(close.rec.economics.maximum_buy, null, 'no call, no ceiling');

  const limited = await go('floor_limited');
  assert.notEqual(limited.p.decision.basis, 'sold_floor', 'a limited pool has no floor');
  assert.notEqual(limited.rec.action, 'BUY');
});

test('14. context is sanitised: unknown fields and bad types are dropped', async () => {
  const r = await run({ raw: pool(155, 17, 120, 190), ask: 60,
    context: { identity: { level: 'certainly', reasons: [1, 2] }, sold_floor: 'abc', evil: '<script>' } });
  assert.equal(r.payload.decision.result, 'BUY', 'an unrecognised identity level is ignored, not trusted');
  assert.equal(r.payload.decision_record.identity.status, 'not_checked');
});

test('15. engine error -> NO_DECISION record, never a fake answer', () => {
  const rec = decisionRecord.noDecisionRecord('BuyMax failed before a decision could be made.');
  assert.equal(rec.action, 'NO_DECISION');
  assert.equal(rec.confidence.level, 'NONE');
});

test('16. what to pay: the ceiling without an ask, copied from the engine', async () => {
  const strong = await run(Object.assign({}, SCENARIOS.strong_buy, { ask: 0 }));
  const w = strong.payload.decision_record.what_to_pay;
  assert.equal(w.max, strong.payload.price_ladder.maximum_buy_price);
  assert.equal(w.market, strong.payload.decision.estimated_resale);
  assert.equal(w.target_margin, 0.3);
  assert.equal(w.confirm_first, false);
  // Same ceiling whatever the ask: the verdict changes, the ceiling does not.
  const at150 = await run(SCENARIOS.strong_walk_away);
  assert.equal(at150.payload.decision_record.what_to_pay.max, w.max);

  const unconf = await run(Object.assign({}, SCENARIOS.numbered_unconfirmed, { ask: 0 }));
  assert.equal(unconf.payload.decision_record.what_to_pay.confirm_first, true);

  for (const k of ['insufficient_two', 'mixed_variants', 'active_only', 'no_comps']) {
    const r = await run(Object.assign({}, SCENARIOS[k], { ask: 0 }));
    assert.equal(r.payload.decision_record.what_to_pay, null, k + ': no ceiling without trustworthy sales');
  }
});

test('17. preview requests are answered but never logged as decisions', async () => {
  const express = require('express');
  const { mountBuyMax } = require('../../buymax');
  const { makeCardGaugeHook } = require('../../buymax-adapter');
  let logged = 0;
  const app = express();
  mountBuyMax(app, { store: { logAnalysis: async () => { logged++; return { id: 'x' }; }, logOutcome: async () => ({ ok: true }) },
    local: { getSoldComps: makeCardGaugeHook(async () => pool(155, 17, 120, 190)),
             getIdentity: async (it) => ({ identity: it, identity_confidence: 85 }) }, deps: {} });
  const srv = await new Promise((ok) => { const s = app.listen(0, () => ok(s)); });
  const post = (b) => fetch('http://127.0.0.1:' + srv.address().port + '/api/buymax',
    { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b) }).then((r) => r.json());
  try {
    const item = { name: '2020 Topps Chrome Luis Robert #1', condition: 'raw' };
    const p = await post({ category: 'card', item, asking_price: 0, preview: true });
    assert.equal(p.meta.preview, true);
    assert.equal(p.meta.analysis_id, undefined);
    assert.equal(logged, 0, 'preview not logged');
    await post({ category: 'card', item, asking_price: 60 });
    assert.equal(logged, 1, 'a real ask is logged');
  } finally { srv.close(); }
});
