'use strict';
/* One fee model (22 Sept): server feeModel(), scanner applyFeeModel(),
   sort page netAfterFees(). Off by default: pages keep their old values. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { config } = require('../../buymax');

const server = fs.readFileSync(path.join(__dirname, '../../server.js'), 'utf8');
const fmSrc = server.slice(server.indexOf('function feeModel() {'), server.indexOf('/* ── THE EVIDENCE RECEIPT'));
const feeModel = new Function('buymaxConfig', fmSrc + '\nreturn feeModel;')(config);

const appDir = [process.env.CG_APP_DIR, path.join(__dirname, '../../../cardgauge-app'), path.join(__dirname, '../../../app')]
  .filter(Boolean).find((d) => fs.existsSync(path.join(d, 'scanner.html')));

test('fee model: one source (BuyMax config), switched off unless FEE_MODEL_UNIFIED=true', () => {
  const prev = process.env.FEE_MODEL_UNIFIED;
  delete process.env.FEE_MODEL_UNIFIED;
  const f = feeModel();
  assert.equal(f.sell_fee_rate, config.costs.sellFeeRate);
  assert.equal(f.payment_fixed, config.costs.paymentFixed);
  assert.equal(f.shipping, config.costs.defaultShipping);
  assert.equal(f.unified, false);
  process.env.FEE_MODEL_UNIFIED = 'true';
  assert.equal(feeModel().unified, true);
  if (prev === undefined) delete process.env.FEE_MODEL_UNIFIED; else process.env.FEE_MODEL_UNIFIED = prev;
});

test('scanner Sell/Keep/Grade: old values while off, server values when on, never a bad value', { skip: !appDir && 'app not found' }, () => {
  const src = fs.readFileSync(path.join(appDir, 'scanner.html'), 'utf8');
  const a = src.indexOf('var SELL_FEE_PCT = 13'), b = src.indexOf('function buildDecision(d, rows, s){');
  const env = new Function(src.slice(a, b) + '\nreturn { apply: applyFeeModel, get: function(){ return [SELL_FEE_PCT, SELL_FIXED, SELL_SHIP]; } };')();
  env.apply({ fees: { sell_fee_rate: 0.1325, payment_fixed: 0.30, shipping: 0, unified: false } });
  assert.deepEqual(env.get(), [13, 0.30, 4], 'off: unchanged');
  env.apply({ fees: { sell_fee_rate: 0.1325, payment_fixed: 0.30, shipping: 1.25, unified: true } });
  assert.deepEqual(env.get(), [13.25, 0.30, 1.25], 'on: the server model');
  env.apply({ fees: { sell_fee_rate: 7, payment_fixed: 0.30, shipping: 1, unified: true } });
  assert.deepEqual(env.get(), [13, 0.30, 4], 'nonsense rate: falls back');
  env.apply({});
  assert.deepEqual(env.get(), [13, 0.30, 4], 'older server: unchanged');
});

test('sort piles: same switch, same numbers', { skip: !(appDir && fs.existsSync(path.join(appDir, 'sort.html'))) && 'sort.html not found' }, () => {
  const src = fs.readFileSync(path.join(appDir, 'sort.html'), 'utf8');
  const a = src.indexOf('var SORT_FEES'), b = src.indexOf('function pileFor(d){');
  const env = new Function(src.slice(a, b) + '\nreturn { use: useFeeModel, net: netAfterFees };')();
  env.use({});
  assert.equal(Math.round(env.net(10) * 100) / 100, 3.9, 'off: 10*0.87 - 0.30 - 4.50');
  env.use({ fees: { sell_fee_rate: 0.1325, payment_fixed: 0.30, shipping: 1.25, unified: true } });
  assert.ok(Math.abs(env.net(10) - (10 * 0.8675 - 0.30 - 1.25)) < 1e-9, 'on: 10*0.8675 - 0.30 - 1.25');
});
