'use strict';
/* Decision Receipt rendering (22 Sept). Renders REAL engine records through
   the receipt function in cardgauge-app/scanner.html.
   Set CG_SCANNER_HTML to that file; skipped when it cannot be found. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { run, SCENARIOS } = require('./scenarios');

const candidates = [process.env.CG_SCANNER_HTML,
  path.join(__dirname, '../../../cardgauge-app/scanner.html'),
  path.join(__dirname, '../../../app/scanner.html')].filter(Boolean);
const file = candidates.find((f) => fs.existsSync(f));

function loadReceipt() {
  const src = fs.readFileSync(file, 'utf8');
  const a = src.indexOf('  var money = function (n) {');
  const b = src.indexOf('  function mount(target, opts) {');
  assert.ok(a > 0 && b > a, 'receipt block found in scanner.html');
  return new Function(src.slice(a, b) + '\nreturn renderDecisionReceipt;')();
}
const text = (html) => html.replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/\s+/g, ' ');

test('receipt renders every action from real engine records', { skip: !file && 'scanner.html not found' }, async () => {
  const receipt = loadReceipt();
  const expect = { strong_buy: 'Buy', strong_walk_away: 'Walk away', numbered_unconfirmed: 'Your call',
                   insufficient_two: 'No decision', floor_clear: 'Buy' };
  for (const [name, word] of Object.entries(expect)) {
    const rec = (await run(SCENARIOS[name])).payload.decision_record;
    const html = receipt(rec);
    const t = text(html);
    assert.ok(html.indexOf('data-action="' + rec.action + '"') > -1, name + ' carries its action');
    assert.ok(t.indexOf('CardGauge decision') > -1, name);
    assert.ok(t.indexOf(word) > -1, name + ' shows ' + word);
    assert.ok(t.indexOf(rec.why) > -1, name + ' shows the engine reason verbatim');
    // Every number shown is the record's number, rounded the panel's way.
    if (rec.economics && rec.economics.maximum_buy !== null) {
      assert.ok(t.indexOf('$' + Math.round(rec.economics.maximum_buy)) > -1, name + ' shows the ceiling');
    }
    assert.ok(!/\d+\s*%\s*(chance|likely|probability)/i.test(t), name + ' never claims a probability');
    if (rec.confidence.level !== 'NONE') assert.ok(t.indexOf('not a probability') > -1, name + ' says confidence is not a probability');
  }
});

test('receipt: BUY shows the full row set; NO_DECISION shows no economics', { skip: !file && 'scanner.html not found' }, async () => {
  const receipt = loadReceipt();
  const buy = text(receipt((await run(SCENARIOS.strong_buy)).payload.decision_record));
  for (const k of ['Market (sold)', 'Ask', 'Maximum buy', 'Expected net', 'Expected profit', 'ROI',
                   'Evidence', 'Evidence quality', 'Risk', 'Confidence', 'What would change this']) {
    assert.ok(buy.indexOf(k) > -1, 'BUY receipt has ' + k);
  }
  const none = text(receipt((await run(SCENARIOS.insufficient_two)).payload.decision_record));
  assert.ok(none.indexOf('Maximum buy') < 0 && none.indexOf('ROI') < 0, 'no ceiling or ROI on a no-decision');
  assert.ok(none.indexOf('What would change this') > -1);
});

test('receipt escapes engine text', { skip: !file && 'scanner.html not found' }, () => {
  const receipt = loadReceipt();
  const html = receipt({ action: 'REVIEW', why: '<img src=x onerror=alert(1)>', market: {}, economics: {},
                         evidence: { quality: 'HIGH' }, risk: {}, confidence: { level: 'LOW', reasons: ['<b>'] },
                         what_would_change: ['"quoted" & <tag>'], alternatives: [] });
  assert.ok(html.indexOf('<img') < 0 && html.indexOf('&lt;img') > -1);
  assert.ok(html.indexOf('<tag>') < 0);
});

test('receipt renders nothing without a record (older server)', { skip: !file && 'scanner.html not found' }, () => {
  const receipt = loadReceipt();
  assert.equal(receipt(null), '');
});

test('what to pay line renders the engine ceiling, or says no decision', { skip: !file && 'scanner.html not found' }, async () => {
  const src = fs.readFileSync(file, 'utf8');
  const a = src.indexOf('function whatToPayHTML(rec){');
  const b = src.indexOf('/* Posts to /api/buymax/outcome');
  const esc = (s) => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const render = new Function('esc', src.slice(a, b) + '\nreturn whatToPayHTML;')(esc);
  const strong = (await run(Object.assign({}, SCENARIOS.strong_buy, { ask: 0 }))).payload.decision_record;
  const t = text(render(strong));
  assert.ok(t.indexOf('What to pay') > -1);
  assert.ok(t.indexOf('$' + Math.round(strong.what_to_pay.max) + ' or less') > -1, t);
  assert.ok(t.indexOf('Target margin 30%') > -1);
  const none = (await run(Object.assign({}, SCENARIOS.insufficient_two, { ask: 0 }))).payload.decision_record;
  const tn = text(render(none));
  assert.ok(tn.indexOf('No decision') > -1 && tn.indexOf('or less') < 0);
  const unconf = (await run(Object.assign({}, SCENARIOS.numbered_unconfirmed, { ask: 0 }))).payload.decision_record;
  assert.ok(text(render(unconf)).indexOf('Confirm the card first') > -1);
});
