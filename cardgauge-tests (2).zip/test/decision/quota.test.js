'use strict';
/* 22 Sept: a failed scan must not use up one of the 25 free daily scans. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { EventEmitter } = require('events');
const src = fs.readFileSync(path.join(__dirname, '../../server.js'), 'utf8');
const a = src.indexOf('const SCAN_REFUNDS_PER_DAY'), b = src.indexOf('\nlet visionGlobalDay', a);
function load() {
  const ticks = [];
  const cache = new Map();
  const f = new Function('envNum', 'userUsageCache', 'userTick', 'console',
    src.slice(a, b) + '\nreturn scanChargeOnSuccess;')(
    (k, d) => d, cache, (uid, day, kind) => { ticks.push(kind); cache.set(uid + '|' + day + '|' + kind, (cache.get(uid + '|' + day + '|' + kind) || 0) + 1); },
    { log() {} });
  return { f, ticks, cache };
}
function fakeRes() {
  const r = new EventEmitter();
  r.statusCode = 200; r.writableFinished = false;
  r.json = function () { r.writableFinished = true; r.emit('finish'); return r; };
  r.end = function () { r.writableFinished = true; r.emit('finish'); return r; };
  r.status = function (c) { r.statusCode = c; return r; };
  return r;
}
const K = 'u|2026-09-22|scan';

test('successful scan is counted once', () => {
  const { f, ticks, cache } = load(); const res = fakeRes();
  f({}, res, 'u', '2026-09-22');
  assert.equal(cache.get(K), 1, 'reserved up front');
  res.json({ success: true });
  assert.deepEqual(ticks, ['scan']); assert.equal(cache.get(K), 1);
});

test('"could not read this card" (200, success:false) is not counted', () => {
  const { f, ticks, cache } = load(); const res = fakeRes();
  f({}, res, 'u', '2026-09-22'); res.json({ success: false, error: 'x' });
  assert.deepEqual(ticks, []); assert.equal(cache.get(K), 0);
});

test('HEIC 415 and server 500 are not counted', () => {
  for (const code of [415, 500]) {
    const { f, ticks, cache } = load(); const res = fakeRes();
    f({}, res, 'u', '2026-09-22'); res.status(code).json({ success: false });
    assert.deepEqual(ticks, [], String(code)); assert.equal(cache.get(K), 0);
  }
});

test('streamed scan whose final line fails is not counted; a good one is', () => {
  let { f, ticks } = load(); let res = fakeRes();
  f({}, res, 'u', '2026-09-22');
  res.end(JSON.stringify({ stage: 'final', success: false, error: 'Scanner failed' }) + '\n');
  assert.deepEqual(ticks, []);
  ({ f, ticks } = load()); res = fakeRes();
  f({}, res, 'u', '2026-09-22');
  res.end(JSON.stringify({ stage: 'final', success: true }) + '\n');
  assert.deepEqual(ticks, ['scan']);
});

test('refunds are capped at 10 a day, then failures count', () => {
  const { f, ticks } = load();
  for (let i = 0; i < 12; i++) { const res = fakeRes(); f({}, res, 'u', '2026-09-22'); res.json({ success: false }); }
  assert.equal(ticks.length, 2);
});

test('a scan the person abandons still counts', () => {
  const { f, ticks } = load(); const res = fakeRes();
  f({}, res, 'u', '2026-09-22'); res.emit('close');
  assert.deepEqual(ticks, ['scan']);
});
