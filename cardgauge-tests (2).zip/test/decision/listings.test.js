'use strict';
/* Listing filter (22 Sept): another sport / another Topps product.
   Cases are the real titles eBay returned for two launch-day scans. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const src = fs.readFileSync(path.join(__dirname, '../../server.js'), 'utf8');
const grab = (a, b) => src.slice(src.indexOf(a), src.indexOf(b, src.indexOf(a)));
const body = grab('function cleanVal(', '\n}\n') + '\n}\n'
  + src.slice(src.indexOf('const SPORT_WORDS = {'), src.indexOf('function selectListings(ai, byTier) {'));
const GENERIC_SET = /^(base|base set|base rookie|base series|base card|common|rookie|rookies|n\/a|none|unknown|-)$/i;
const JUNK_VALUE = /^(unknown|n\/a|none|-|null|)$/i;
const conflicts = new Function('GENERIC_SET', 'JUNK_VALUE', body + '\nreturn listingConflictsCard;')(GENERIC_SET, JUNK_VALUE);

test('football scan drops the NBA player of the same name, keeps the right card', () => {
  const ai = { sport: 'Football', brand: 'Panini', set: 'Prizm', player: 'Justin Jackson' };
  assert.ok(conflicts('2018-19 Donruss Optic JUSTIN JACKSON Choice Prizm Signatures Auto Rated Rookie', ai));
  assert.ok(conflicts('Justin Jackson 2018 Prizm NBA Rookie Auto Mavericks', ai));
  for (const t of ['2018 Panini Prizm #RA-JU Justin Jackson Auto RC Prizm Gold #/10 Chargers',
                   '2018 Panini Prizm - Rookie Auto - Justin Jackson - Pink Prizm - LA Chargers',
                   'justin jackson auto', '2018 Prizm Autographs Pink Refractor Justin Jackson Rookie Auto NFL']) {
    assert.equal(conflicts(t, ai), null, t);
  }
});

test('flagship Topps scan drops other Topps products, keeps flagship', () => {
  const ai = { sport: 'Baseball', brand: 'Topps', set: '', player: 'CJ Abrams', serialNumber: '087/499' };
  for (const t of ['2023 Bowman Chrome CJ ABRAMS Refractor Card /499 #74 Washington Nationals',
                   '2023 Chrome Platinum #319 CJ Abrams Topps Logo Refractors #/499',
                   '2023 Topps Chrome CJ ABRAMS Green Ice Refractor 036/499 NATIONALS #35',
                   '2023 Topps Heritage CJ Abrams /499', '2023 Topps Now CJ Abrams /499']) {
    assert.ok(conflicts(t, ai), t);
  }
  for (const t of ['2023 Topps #35 CJ Abrams Green Foil #/499',
                   'CJ ABRAMS 2023 TOPPS FUTURE STARS GREEN FOIL REFRACTOR /499 MINT',
                   '2023 Topps Series 1 CJ Abrams #35 Future Stars Green Foil /499 WAS Nationals',
                   'CJ Abrams 2022 Topps Update Series Green Icy Foil Rookie RC /499 NATIONALS',
                   '2023 Topps CJ Abrams Buy It Now /499']) {
    assert.equal(conflicts(t, ai), null, t);
  }
});

test('the filter never touches a card whose own set names that product', () => {
  const chrome = { sport: 'Baseball', brand: 'Topps', set: 'Chrome', player: 'CJ Abrams' };
  assert.equal(conflicts('2023 Topps Chrome CJ ABRAMS Green Ice Refractor 036/499', chrome), null);
  const withInsert = { sport: 'Baseball', brand: 'Topps', set: '', insert: 'Stadium Club Chrome', player: 'X' };
  assert.equal(conflicts('2023 Topps Stadium Club Chrome X', withInsert), null, 'insert named: filter off');
});

test('no sport, Pokemon or soccer: nothing is dropped for sport', () => {
  assert.equal(conflicts('2018-19 Panini Prizm Luka Doncic NBA', { sport: '', brand: 'Panini' }), null);
  assert.equal(conflicts('Pikachu 2023 basketball promo', { sport: 'Pokemon', brand: 'Pokemon' }), null);
  assert.equal(conflicts('2023-24 Topps Chrome UEFA Messi', { sport: 'Soccer', brand: 'Topps', set: 'Chrome' }), null);
});

test('basketball and hockey keep their season-dated titles', () => {
  assert.equal(conflicts('2018-19 Panini Prizm Luka Doncic RC', { sport: 'Basketball', brand: 'Panini', set: 'Prizm' }), null);
  assert.equal(conflicts('2015-16 Upper Deck Young Guns Connor McDavid', { sport: 'Hockey', brand: 'Upper Deck' }), null);
  assert.ok(conflicts('2018 Panini Prizm Justin Jackson NFL Chargers', { sport: 'Basketball', brand: 'Panini', set: 'Prizm' }));
});

test('a print run is not a season date (2023 /50 stays; 2024-25 goes)', () => {
  const ai = { sport: 'Football', brand: 'Panini', set: 'Prizm', player: 'Tom Brady' };
  assert.equal(conflicts('Tom Brady 2023 /50 Prizm Gold', ai), null);
  assert.equal(conflicts('2021 Topps Chrome Tatis 2021 /25', { sport: 'Baseball', brand: 'Topps', set: 'Chrome' }), null);
  assert.ok(conflicts('Bo Nix 2024-25 Prizm Gold', ai));
  assert.ok(conflicts('Bo Nix 2024/25 Prizm Gold', ai));
});
