'use strict';
/* PRICE TARGET CROSSING TESTS (23 Sept).

   targetVerdict is the whole feature in one pure function: given a user's
   number, today's price, where the price was when we last emailed, how
   many sales are behind the number and whether the engine would price the
   card at all — does an email go out?

   It is pulled out of server.js the same way server-helpers.js pulls the
   other helpers, so these test the shipped code rather than a copy.

   The refusal cases matter more than the firing ones. This is the single
   screen where somebody acts on a number by actually selling a card, so
   an alert off a pool CompGuard would not price, or off two sales, is the
   most expensive possible mistake. */
const test   = require('node:test');
const assert = require('node:assert/strict');
const fs     = require('fs');
const path   = require('path');

const src = fs.readFileSync(path.join(__dirname, '../../server.js'), 'utf8');
const a = src.indexOf('function targetVerdict(');
const b = src.indexOf('\n}', src.indexOf('return { fire: true, rearm: false, why: "crossed" };', a)) + 2;
if (a < 0 || b < 2) throw new Error('targetVerdict not found in server.js');
const MIN_SALES = 3;
const targetVerdict = new Function('TARGET_MIN_SALES', src.slice(a, b) + '\nreturn targetVerdict;')(MIN_SALES);

const ok = (o) => Object.assign({ sales: 9, priced: true, lastAlerted: null }, o);

test('sell target — fires the first time it crosses, once', () => {
  assert.equal(targetVerdict(ok({ direction: 'above', target: 200, current: 180 })).fire, false);
  assert.equal(targetVerdict(ok({ direction: 'above', target: 200, current: 205 })).fire, true);
  assert.equal(targetVerdict(ok({ direction: 'above', target: 200, current: 200 })).fire, true,
    'exactly on the number counts as reaching it');
});

test('sell target — does not fire again while it sits above', () => {
  const v = targetVerdict(ok({ direction: 'above', target: 200, current: 210, lastAlerted: 205 }));
  assert.equal(v.fire, false, 'a card resting above the target is one email, not one a day');
  assert.equal(v.rearm, false);
});

test('sell target — re-arms when it falls back, then fires again', () => {
  const back = targetVerdict(ok({ direction: 'above', target: 200, current: 190, lastAlerted: 205 }));
  assert.equal(back.fire, false);
  assert.equal(back.rearm, true, 'falling back past the target clears the marker');

  const again = targetVerdict(ok({ direction: 'above', target: 200, current: 207, lastAlerted: 190 }));
  assert.equal(again.fire, true, 'a genuine second crossing is a genuine second email');
});

test('buy target — mirrors the sell case in the other direction', () => {
  assert.equal(targetVerdict(ok({ direction: 'below', target: 75, current: 88 })).fire, false);
  assert.equal(targetVerdict(ok({ direction: 'below', target: 75, current: 72 })).fire, true);
  assert.equal(targetVerdict(ok({ direction: 'below', target: 75, current: 70, lastAlerted: 72 })).fire, false);
  assert.equal(targetVerdict(ok({ direction: 'below', target: 75, current: 80, lastAlerted: 72 })).rearm, true);
});

test('a refused price never fires — CompGuard withheld the median', () => {
  const v = targetVerdict(ok({ direction: 'above', target: 200, current: 205, priced: false }));
  assert.equal(v.fire, false);
  assert.equal(v.rearm, false, 'a paused target must not silently re-arm either');
  assert.match(v.why, /refused/);
});

test('a thin pool never fires, and the floor is inclusive', () => {
  assert.equal(targetVerdict(ok({ direction: 'above', target: 200, current: 205, sales: 2 })).fire, false,
    'two sales are not a market');
  assert.equal(targetVerdict(ok({ direction: 'above', target: 200, current: 205, sales: 0 })).fire, false);
  assert.equal(targetVerdict(ok({ direction: 'above', target: 200, current: 205, sales: MIN_SALES })).fire, true,
    'exactly at the floor is enough');
});

test('missing inputs decline rather than guess', () => {
  assert.equal(targetVerdict(ok({ direction: 'above', target: 200, current: 0 })).fire, false);
  assert.equal(targetVerdict(ok({ direction: 'above', target: 0,   current: 205 })).fire, false);
  assert.equal(targetVerdict(ok({ direction: 'above', target: null, current: 205 })).fire, false);
  assert.equal(targetVerdict(ok({ direction: 'above', target: 200, current: null })).fire, false);
});

test('an unknown direction is treated as a sell target, never as both', () => {
  const v = targetVerdict(ok({ direction: 'sideways', target: 200, current: 205 }));
  assert.equal(v.fire, true, 'defaults to above');
  assert.equal(targetVerdict(ok({ direction: 'sideways', target: 200, current: 190 })).fire, false);
});

test('it computes no price of its own', () => {
  /* The verdict is a comparison, not a calculation: the same inputs with a
     different current price may flip the answer, but nothing in here can
     invent or round a number the engine did not produce. */
  const body = src.slice(a, b);
  assert.ok(!/median|trimmed|Math\.round|toFixed/.test(body),
    'targetVerdict must not do arithmetic on prices');
});

/* WHICH COUNT THE FLOOR IS READ AGAINST (24 Sept).

   targetVerdict takes a number and trusts it. The bug was not in here
   -- it was in what runTargetAlerts handed it: sold_count, the rows the
   API returned, rather than verified_count, the rows that survived
   CompGuard and formed the median.

   Extracted and tested the same way as the verdict itself, because the
   distinction is the whole safety of the feature: a card can return 89
   results and price off 4. */
const salesBehindSrc = (() => {
  const i = src.indexOf('const salesBehind = (h) => {');
  if (i < 0) throw new Error('salesBehind not found in server.js');
  const j = src.indexOf('};', i) + 2;
  return src.slice(i, j);
})();
const salesBehind = new Function(salesBehindSrc + '\nreturn salesBehind;')();

test('the floor counts verified sales, not everything the API returned', () => {
  assert.equal(salesBehind({ sold_count: 89, verified_count: 4 }), 4,
    'the 2017 Prizm Mahomes case: 89 results, 4 survived CompGuard');
  assert.equal(salesBehind({ sold_count: 100, verified_count: 1 }), 1,
    'a hundred results resting on one sale must read as one');
  assert.equal(salesBehind({ sold_count: 100, verified_count: 0 }), 0,
    'zero verified is zero, never the raw count');
});

test('rows written before verified_count existed fall back, and nothing else does', () => {
  assert.equal(salesBehind({ sold_count: 12, verified_count: null }), 12,
    'null means the column did not exist yet — sold_count is all there is');
  assert.equal(salesBehind({ sold_count: 12 }), 12, 'undefined behaves the same');
  assert.equal(salesBehind(null), 0, 'no history row at all is no sales');
});

test('a hundred raw results with one verified sale cannot fire an alert', () => {
  const v = targetVerdict({
    direction: 'above', target: 200, current: 205, priced: true, lastAlerted: null,
    sales: salesBehind({ sold_count: 100, verified_count: 1 })
  });
  assert.equal(v.fire, false, 'this is the email that must never send');
});
