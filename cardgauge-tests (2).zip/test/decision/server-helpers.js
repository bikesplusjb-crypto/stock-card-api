'use strict';
/* Pulls two functions out of server.js without starting the server, the
   same way the regression harness reads it: buildEvidenceReceipt and the
   BuyMax store (logAnalysis / logOutcome). */
const fs = require('fs');
const path = require('path');
const src = fs.readFileSync(path.join(__dirname, '../../server.js'), 'utf8');
const { decisionRecord, config } = require('../../buymax');

function slice(startMarker, endMarker) {
  const a = src.indexOf(startMarker), b = src.indexOf(endMarker, a);
  if (a < 0 || b < 0) throw new Error('marker not found: ' + startMarker);
  return src.slice(a, b);
}

function evidenceReceipt() {
  const body = slice('function buildEvidenceReceipt(sold, market, f) {', 'function askVsSold(market, sold) {');
  return new Function('decisionRecord', 'buymaxConfig', 'CARDAPI_LOOKBACK',
    body + '\nreturn buildEvidenceReceipt;')(decisionRecord, config, 14);
}

function buymaxStore(supabaseAdmin) {
  const body = slice('const buymaxStore = {', 'mountBuyMax(app, {');
  return new Function('supabaseAdmin', body + '\nreturn buymaxStore;')(supabaseAdmin);
}

module.exports = { evidenceReceipt, buymaxStore };
