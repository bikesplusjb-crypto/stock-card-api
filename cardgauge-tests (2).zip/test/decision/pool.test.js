'use strict';
/* 22 Sept: a common card read "prices all over the place" because one or
   two strays set the range. And set-fill called a Topps card ambiguous
   because a Panini card shared its number. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const src = fs.readFileSync(path.join(__dirname, '../../server.js'), 'utf8');
const cut = (a, b) => src.slice(src.indexOf(a), src.indexOf(b, src.indexOf(a)));
const fns = new Function(
  cut('function median(sortedNums) {', '// Detect a graded slab') +
  cut('function brandFamily(name) {', 'function setFillKey(ai) {') +
  '\nreturn { median, trimmedRange, clusterRange, poolRange, brandFamily };')();

test('one card plus strays: the range is the cluster, not the strays', () => {
  // 2024 Bowman Pete Crow-Armstrong #85, the real raw pool
  const r = fns.poolRange([1.75, 2, 2.25, 2.25, 3.99, 8.5, 23]);
  assert.deepEqual(r, { low: 2, high: 4 });
});

test('a real two-version pool still reads as spread', () => {
  // Dark Charizard: 21/82 non-holo mixed with 4/82 holo
  assert.equal(fns.clusterRange([96.06, 124.99, 135, 399.99, 480]), null);
  assert.equal(fns.clusterRange([2, 2, 2, 30, 30, 30]), null, 'half base, half parallel');
});

test('small pools keep the old range', () => {
  assert.equal(fns.clusterRange([2, 3, 20]), null);
  assert.deepEqual(fns.poolRange([2, 3, 20]), fns.trimmedRange([2, 3, 20]));
});

test('brand family: Topps card never matches a Panini product', () => {
  assert.equal(fns.brandFamily('Topps'), 'topps');
  assert.equal(fns.brandFamily('2024 Bowman'), 'topps');
  assert.equal(fns.brandFamily('2024 Donruss'), 'panini');
  assert.equal(fns.brandFamily('2023 Panini Prizm'), 'panini');
  assert.equal(fns.brandFamily('2015 Upper Deck'), 'upperdeck');
  assert.equal(fns.brandFamily('Leaf'), null);
  assert.equal(fns.brandFamily(''), null);
});
