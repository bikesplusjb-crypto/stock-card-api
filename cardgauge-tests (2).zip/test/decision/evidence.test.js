'use strict';
/* The evidence receipt on every scan / typed result (server.js
   buildEvidenceReceipt) and outcome recording (buymaxStore). */
const test = require('node:test');
const assert = require('node:assert/strict');
const { evidenceReceipt, buymaxStore } = require('./server-helpers');
const build = evidenceReceipt();

const pool = (median, count, low, high, extra) => Object.assign({
  soldCount: count, soldMedian: median, soldLow: low, soldHigh: high,
  soldRaw: { count, median, low, high }, soldRawBasis: 'base', lookbackDays: 14,
  lastSaleDate: new Date(Date.now() - 2 * 86400000).toISOString().slice(0, 10)
}, extra || {});
const market = { avgPrice: 160 };

test('evidence: clean deep pool -> HIGH, with what we know and a would-change line', () => {
  const e = build(pool(155, 17, 130, 180), market, {});
  assert.equal(e.quality, 'HIGH');
  assert.equal(e.value, 155);
  assert.equal(e.basis, 'sold_median');
  assert.ok(e.known.some((x) => /17 completed sales in the last 14 days/.test(x)));
  assert.ok(e.known.some((x) => /Newest sale 2 days ago/.test(x)));
  assert.equal(e.unknown.length, 0);
  assert.ok(e.would_change.some((x) => /below \$130/.test(x)));
  assert.ok(/not a probability/.test(e.meaning));
});

test('evidence: 4 sales -> THIN (scanner label line is 5), says so in unknowns', () => {
  const e = build(pool(40, 4, 35, 45), market, {});
  assert.equal(e.quality, 'THIN');
  assert.ok(e.unknown.some((x) => /4 sales are typical/.test(x)));
});

test('evidence: two sales -> INSUFFICIENT, no value printed', () => {
  const e = build(pool(40, 2, 35, 45), market, {});
  assert.equal(e.quality, 'INSUFFICIENT');
  assert.equal(e.value, null);
});

test('evidence: contaminated pool -> REFUSED, no value', () => {
  const e = build(pool(40, 30, 10, 90, { soldContaminated: true }), market, {});
  assert.equal(e.quality, 'REFUSED');
  assert.equal(e.value, null);
  assert.ok(e.would_change[0].indexOf('one version') > -1);
});

test('evidence: wide base pool -> MIXED', () => {
  assert.equal(build(pool(50, 20, 40, 60, { soldWideBase: true }), market, {}).quality, 'MIXED');
  assert.equal(build(pool(50, 20, 5, 400), market, {}).quality, 'MIXED', '3x spread');
});

test('evidence: print run dropped -> INDIRECT and named in what we do not know', () => {
  const e = build(pool(6, 33, 4, 9), market, { serialDropped: true, serialRead: '/149' });
  assert.equal(e.quality, 'INDIRECT');
  assert.ok(e.unknown.some((x) => /\/149 itself sells for/.test(x)));
});

test('evidence: broadened search and year swap -> INDIRECT', () => {
  assert.equal(build(pool(20, 12, 15, 25), market, { soldBroadened: { to: 'x' } }).quality, 'INDIRECT');
  assert.equal(build(pool(20, 12, 15, 25), market, { yearGuess: { claimedYear: '2023', triedYear: '2024' } }).quality, 'INDIRECT');
});

test('evidence: colour-only parallel is an unknown, not a downgrade', () => {
  const e = build(pool(155, 17, 130, 180), market, { parallel: 'Blue Parallel', parallelCertain: false });
  assert.equal(e.quality, 'HIGH');
  assert.ok(e.unknown.some((x) => /Blue Parallel: it was judged from colour/.test(x)));
});

test('evidence: no sales but asks -> ACTIVE_ONLY; nothing -> NONE', () => {
  const a = build(null, market, {});
  assert.equal(a.quality, 'ACTIVE_ONLY');
  assert.equal(a.basis, 'asking_prices');
  assert.equal(a.value, null, 'an ask is never shown as a sold value');
  assert.ok(a.unknown.some((x) => /an ask is not a sale/.test(x)));
  assert.equal(build(null, { avgPrice: 0 }, {}).quality, 'NONE');
});

test('evidence: stale newest sale is an unknown', () => {
  const e = build(pool(155, 17, 130, 180, { lastSaleDate: new Date(Date.now() - 12 * 86400000).toISOString().slice(0, 10) }), market, {});
  assert.ok(e.unknown.some((x) => /12 days since the last sale/.test(x)));
});

test('evidence: catalog could not find the number -> unknown', () => {
  const e = build(pool(155, 17, 130, 180), market, { verified: { checked: true, exists: false } });
  assert.ok(e.unknown.some((x) => /catalog could not find it/.test(x)));
});

test('evidence: redemption voucher -> NONE with its own explanation', () => {
  const e = build(pool(155, 17, 130, 180), market, { isRedemption: true });
  assert.equal(e.quality, 'NONE');
  assert.equal(e.value, null);
});

test('evidence: a malformed pool never throws (returns null or a receipt)', () => {
  assert.doesNotThrow(() => build({ soldRaw: 'nope', soldCount: 'x' }, null, null));
});

test('outcome recording: decision stored whole; bought then sold keeps both prices', async () => {
  let inserted = null; const patches = [];
  const db = { from: () => ({
    insert: (row) => { inserted = row; return { select: () => ({ single: async () => ({ data: { id: 'a1' } }) }) }; },
    update: (p) => { patches.push(p); return { eq: () => ({ select: async () => ({ data: [{ id: 'a1' }] }) }) }; } }) };
  const store = buymaxStore(db);
  const { run, SCENARIOS } = require('./scenarios');
  const payload = (await run(SCENARIOS.strong_buy)).payload;
  const out = await store.logAnalysis(payload, { asking_price: 60 });
  assert.equal(out.id, 'a1');
  assert.equal(inserted.canonical_decision, 'BUY');
  assert.equal(inserted.evidence_quality, 'HIGH');
  assert.equal(inserted.decision_record.economics.maximum_buy, payload.price_ladder.maximum_buy_price);
  assert.equal(inserted.decision, 'BUY', 'legacy column unchanged');

  assert.equal((await store.logOutcome('a1', { action: 'bought', paid_price: 58 })).ok, true);
  assert.equal((await store.logOutcome('a1', { action: 'sold', sold_price: 150 })).ok, true);
  assert.equal(patches[0].outcome_paid_price, 58);
  assert.ok(patches[0].outcome_bought_at);
  assert.ok(!('outcome_paid_price' in patches[1]), 'reporting the sale does not wipe the purchase price');
  assert.equal(patches[1].outcome_sold_price, 150);
  assert.ok(patches[1].outcome_sold_at);
  assert.equal((await store.logOutcome('a1', { action: 'teleported' })).ok, false, 'unknown actions refused');
});

test('evidence: a refusal stays a refusal when the search was also indirect (no value leaks)', () => {
  const e = build(pool(40, 30, 10, 90, { soldContaminated: true }), market, { soldBroadened: { to: 'x' } });
  assert.equal(e.quality, 'REFUSED');
  assert.equal(e.value, null);
  const t = build(pool(40, 2, 35, 45), market, { serialDropped: true, serialRead: '/99' });
  assert.equal(t.quality, 'INSUFFICIENT');
  assert.equal(t.value, null);
});

test('evidence: soldLimited is a refusal even with a median', () => {
  const e = build(pool(40, 12, 30, 50, { soldLimited: true }), market, {});
  assert.equal(e.value, null);
  assert.notEqual(e.quality, 'HIGH');
});

test('evidence: a range across numbered versions prints no single value', () => {
  const e = build(pool(60, 12, 20, 150, { mixedSerials: true }), market, {});
  assert.equal(e.quality, 'INDIRECT');
  assert.equal(e.value, null);
  assert.equal(e.basis, 'numbered_range');
});
