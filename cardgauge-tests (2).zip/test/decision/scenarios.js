'use strict';
/* Shared scenarios for the decision tests. Every sold pool goes through the
   REAL buymax-adapter (so CompGuard refusals are the production ones) and the
   REAL BuyMax engine. Only the data sources are stubbed: no network. */
const { runBuyMax, config, makeLocalProvider } = require('../../buymax');
const { makeCardGaugeHook } = require('../../buymax-adapter');

const ITEM = { name: '2020 Topps Chrome Luis Robert #1', player: 'Luis Robert', year: '2020',
               card_number: '1', condition: 'raw' };

function pool(median, count, low, high) {
  return { soldMedian: median, soldCount: count, soldLow: low, soldHigh: high,
           soldRaw: { count, median, low, high }, soldBasis: 'raw' };
}
function listings(n, price) {
  const out = [];
  for (let i = 0; i < n; i++) {
    out.push({ listing_id: 'L' + i, title: '2020 Topps Chrome Luis Robert #1 RC', price: price + i,
               currency: 'USD', condition: 'Ungraded', buying_format: 'FIXED_PRICE', bid_count: null,
               seller: 's' + i, seller_feedback: 99, categories: [] });
  }
  return out;
}

async function run({ raw = null, ask, item = ITEM, context, active = [], identityConfidence = 85 } = {}) {
  const cfg = config;
  const cardgauge = makeLocalProvider(cfg, {
    getSoldComps: makeCardGaugeHook(async () => raw),
    getIdentity: async (it) => ({ identity: it, identity_confidence: identityConfidence }),
  });
  const ebay = {
    name: 'ebay_active', kind: 'marketplace', isConfigured: () => true,
    // Configured and answering, as in production -- an empty search is still an answer.
    fetch: async () => ({ available: true, listings: active, query: null, errors: [] }),
  };
  const body = { category: 'card', item, asking_price: ask };
  if (context) body.context = context;
  return runBuyMax(body, { cfg, providers: { cardgauge, ebay } });
}

const SCENARIOS = {
  strong_buy:        { raw: pool(155, 17, 120, 190), ask: 60 },
  strong_walk_away:  { raw: pool(155, 17, 120, 190), ask: 150 },
  borderline:        null, // filled in the test from the real ceiling
  insufficient_two:  { raw: pool(40, 2, 35, 45), ask: 10 },
  one_sale_plus_asks:{ raw: pool(40, 1, 40, 40), ask: 10, active: listings(6, 38) },
  active_only:       { raw: null, ask: 10, active: listings(8, 40) },
  contaminated:      { raw: Object.assign(pool(40, 30, 10, 90), { soldContaminated: true }), ask: 10 },
  mixed_variants:    { raw: pool(50, 20, 5, 400), ask: 10 },
  grade_unknown:     { raw: pool(155, 17, 120, 190), ask: 60, item: Object.assign({}, ITEM, { condition: null }) },
  numbered_unconfirmed: { raw: pool(155, 17, 120, 190), ask: 60,
                          item: Object.assign({}, ITEM, { serial_number: '/149', parallel: 'Refractor' }),
                          context: { identity: { level: 'uncertain', reasons: ['the print run is not confirmed'] } } },
  no_comps:          { raw: null, ask: 10 },
  // The cheapest-sale test only runs where the old panel's did: a withheld
  // pool that still reached the refusal branch, i.e. with an active estimate.
  floor_clear:       { raw: Object.assign(pool(60, 30, 40, 200), { soldContaminated: true }), ask: 5,
                       active: listings(8, 55), context: { sold_floor: 40 } },
  floor_too_close:   { raw: Object.assign(pool(60, 30, 40, 200), { soldContaminated: true }), ask: 30,
                       active: listings(8, 55), context: { sold_floor: 40 } },
  floor_unconfirmed: { raw: Object.assign(pool(60, 30, 40, 200), { soldContaminated: true }), ask: 5,
                       active: listings(8, 55),
                       context: { sold_floor: 40, identity: { level: 'uncertain', reasons: ['the product was not read'] } } },  // "limited" = too few clean sales of THIS card; its cheapest sale is not a floor.
  floor_limited:     { raw: Object.assign(pool(60, 30, 40, 200), { soldLimited: true }), ask: 5,
                       active: listings(8, 55), context: { sold_floor: 40 } },
};

module.exports = { run, pool, listings, ITEM, SCENARIOS };
